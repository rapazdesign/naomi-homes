export const site = {
  name: 'Naomi Homes',
  url: 'https://naomihomes.es',
  email: 'rapazdesign@gmail.com',
  phoneDisplay: '+34 604 48 54 45',
  whatsappNumber: '34604485445',
  address: 'San Pedro del Pinatar, Murcia',
}

export function whatsappUrl(message: string) {
  return `https://wa.me/${site.whatsappNumber}?text=${encodeURIComponent(message)}`
}
