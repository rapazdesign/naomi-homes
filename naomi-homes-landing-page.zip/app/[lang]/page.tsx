import { notFound } from 'next/navigation'
import { Gallery } from '@/components/gallery'
import { Hero } from '@/components/hero'
import { Intro } from '@/components/intro'
import { Materials } from '@/components/materials'
import { Process } from '@/components/process'
import { QuoteSection } from '@/components/quote-section'
import { SiteFooter } from '@/components/site-footer'
import { SiteHeader } from '@/components/site-header'
import { WhatsAppButton } from '@/components/whatsapp-button'
import { getDictionary, isLocale } from '@/lib/i18n'
import { site } from '@/lib/site'

export default async function Page({ params }: { params: Promise<{ lang: string }> }) {
  const { lang } = await params
  if (!isLocale(lang)) notFound()
  const t = getDictionary(lang)

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'HomeAndConstructionBusiness',
    name: site.name,
    url: site.url,
    email: site.email,
    telephone: site.phoneDisplay,
    description: t.meta.description,
    image: `${site.url}/images/hero-naomi-kitchen.jpg`,
    address: {
      '@type': 'PostalAddress',
      addressLocality: 'San Pedro del Pinatar',
      addressRegion: 'Murcia',
      addressCountry: 'ES',
    },
    areaServed: t.areas.list,
  }

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <SiteHeader lang={lang} t={t.nav} />
      <main>
        <Hero t={t.hero} />
        <Intro t={t.intro} stats={t.stats} />
        <Materials t={t.materials} />
        <Gallery t={t.gallery} />
        <Process t={t.process} areas={t.areas} />
        <QuoteSection t={t.quote} materials={t.materials.items} />
      </main>
      <SiteFooter t={t.footer} nav={t.nav} />
      <WhatsAppButton label={t.whatsapp.label} message={t.whatsapp.defaultMessage} />
    </>
  )
}
