import Image from 'next/image'
import type { Dictionary } from '@/lib/i18n'
import { SectionHeading } from './section-heading'

export function Materials({ t }: { t: Dictionary['materials'] }) {
  return (
    <section
      id="materials"
      aria-labelledby="materials-title"
      className="scroll-mt-20 bg-primary py-24 text-primary-foreground lg:py-36"
    >
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <SectionHeading id="materials-title" eyebrow={t.eyebrow} title={t.title} />
          <p className="max-w-sm text-pretty leading-relaxed text-primary-foreground/70">{t.body}</p>
        </div>

        <ul className="mt-16 grid gap-px bg-primary-foreground/15 sm:grid-cols-2 lg:mt-20 lg:grid-cols-4">
          {t.items.map((item, i) => (
            <li key={item.id} className="group flex flex-col bg-primary">
              <div className="relative aspect-square overflow-hidden">
                <Image
                  src={item.image}
                  alt={item.alt}
                  fill
                  sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
                  className="object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-110"
                />
                <span className="absolute left-5 top-5 font-serif text-sm text-primary-foreground mix-blend-difference">
                  {String(i + 1).padStart(2, '0')}
                </span>
              </div>
              <div className="flex flex-1 flex-col p-6 lg:p-8">
                <p className="text-[0.65rem] uppercase tracking-[0.25em] text-accent">{item.tagline}</p>
                <h3 className="mt-3 font-serif text-3xl font-light">{item.name}</h3>
                <p className="mt-4 text-sm leading-relaxed text-primary-foreground/70">{item.body}</p>
                <ul className="mt-6 flex flex-col gap-2 border-t border-primary-foreground/15 pt-5 text-xs uppercase tracking-[0.15em] text-primary-foreground/80">
                  {item.specs.map((spec) => (
                    <li key={spec}>{spec}</li>
                  ))}
                </ul>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
