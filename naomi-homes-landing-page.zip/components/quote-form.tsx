'use client'

import { ArrowRight, CheckCircle2 } from 'lucide-react'
import { useState } from 'react'
import type { Dictionary } from '@/lib/i18n'
import { site, whatsappUrl } from '@/lib/site'
import { cn } from '@/lib/utils'
import { WhatsAppIcon } from './whatsapp-icon'

type Fields = {
  name: string
  phone: string
  email: string
  location: string
  material: string
  meters: string
  message: string
  privacy: boolean
}

const initial: Fields = {
  name: '',
  phone: '',
  email: '',
  location: '',
  material: '',
  meters: '',
  message: '',
  privacy: false,
}

type Errors = Partial<Record<keyof Fields, string>>

export function QuoteForm({
  t,
  materials,
}: {
  t: Dictionary['quote']
  materials: { id: string; name: string }[]
}) {
  const [fields, setFields] = useState<Fields>(initial)
  const [errors, setErrors] = useState<Errors>({})
  const [sent, setSent] = useState(false)

  const update = <K extends keyof Fields>(key: K, value: Fields[K]) => {
    setFields((f) => ({ ...f, [key]: value }))
    if (errors[key]) setErrors((e) => ({ ...e, [key]: undefined }))
  }

  const validate = (): Errors => {
    const e: Errors = {}
    if (!fields.name.trim()) e.name = t.required
    if (!fields.phone.trim()) e.phone = t.required
    else if (!/^[+\d][\d\s().-]{7,}$/.test(fields.phone.trim())) e.phone = t.invalidPhone
    if (fields.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email.trim()))
      e.email = t.invalidEmail
    if (!fields.location.trim()) e.location = t.required
    if (!fields.privacy) e.privacy = t.required
    return e
  }

  const materialLabel = () =>
    materials.find((m) => m.id === fields.material)?.name ?? (fields.material ? t.materialUnsure : '-')

  const composeMessage = () =>
    [
      t.whatsappIntro,
      '',
      `${t.name}: ${fields.name.trim()}`,
      `${t.phone}: ${fields.phone.trim()}`,
      fields.email.trim() ? `${t.email}: ${fields.email.trim()}` : null,
      `${t.location}: ${fields.location.trim()}`,
      `${t.material}: ${materialLabel()}`,
      fields.meters.trim() ? `${t.meters}: ${fields.meters.trim()}` : null,
      fields.message.trim() ? `\n${fields.message.trim().slice(0, 1000)}` : null,
    ]
      .filter((line) => line !== null)
      .join('\n')

  const onSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length > 0) {
      const first = Object.keys(e)[0]
      document.getElementById(`quote-${first}`)?.focus()
      return
    }
    window.open(whatsappUrl(composeMessage()), '_blank', 'noopener,noreferrer')
    setSent(true)
  }

  const onEmail = () => {
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length > 0) return
    const subject = encodeURIComponent('Naomi Homes — Presupuesto / Quote')
    window.location.href = `mailto:${site.email}?subject=${subject}&body=${encodeURIComponent(composeMessage())}`
  }

  return (
    <form
      noValidate
      onSubmit={onSubmit}
      className="border border-border bg-card p-6 sm:p-10 lg:p-12"
      aria-describedby={sent ? 'quote-success' : undefined}
    >
      <div className="grid gap-x-8 gap-y-7 sm:grid-cols-2">
        <Field id="name" label={t.name} error={errors.name} required>
          <input
            id="quote-name"
            name="name"
            autoComplete="name"
            value={fields.name}
            onChange={(e) => update('name', e.target.value)}
            className={inputClass(errors.name)}
            aria-invalid={!!errors.name}
            aria-describedby={errors.name ? 'quote-name-error' : undefined}
            maxLength={120}
          />
        </Field>
        <Field id="phone" label={t.phone} error={errors.phone} required>
          <input
            id="quote-phone"
            name="phone"
            type="tel"
            autoComplete="tel"
            value={fields.phone}
            onChange={(e) => update('phone', e.target.value)}
            className={inputClass(errors.phone)}
            aria-invalid={!!errors.phone}
            aria-describedby={errors.phone ? 'quote-phone-error' : undefined}
            maxLength={30}
          />
        </Field>
        <Field id="email" label={t.email} error={errors.email}>
          <input
            id="quote-email"
            name="email"
            type="email"
            autoComplete="email"
            value={fields.email}
            onChange={(e) => update('email', e.target.value)}
            className={inputClass(errors.email)}
            aria-invalid={!!errors.email}
            aria-describedby={errors.email ? 'quote-email-error' : undefined}
            maxLength={160}
          />
        </Field>
        <Field id="location" label={t.location} error={errors.location} required>
          <input
            id="quote-location"
            name="location"
            autoComplete="address-level2"
            value={fields.location}
            onChange={(e) => update('location', e.target.value)}
            className={inputClass(errors.location)}
            aria-invalid={!!errors.location}
            aria-describedby={errors.location ? 'quote-location-error' : undefined}
            maxLength={120}
          />
        </Field>
        <Field id="material" label={t.material}>
          <select
            id="quote-material"
            name="material"
            value={fields.material}
            onChange={(e) => update('material', e.target.value)}
            className={cn(inputClass(), 'appearance-none bg-transparent')}
          >
            <option value="">{t.materialPlaceholder}</option>
            {materials.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name}
              </option>
            ))}
            <option value="unsure">{t.materialUnsure}</option>
          </select>
        </Field>
        <Field id="meters" label={t.meters}>
          <input
            id="quote-meters"
            name="meters"
            inputMode="decimal"
            value={fields.meters}
            onChange={(e) => update('meters', e.target.value.replace(/[^\d.,]/g, ''))}
            className={inputClass()}
            maxLength={8}
          />
        </Field>
        <div className="sm:col-span-2">
          <Field id="message" label={t.message}>
            <textarea
              id="quote-message"
              name="message"
              rows={4}
              placeholder={t.messagePlaceholder}
              value={fields.message}
              onChange={(e) => update('message', e.target.value)}
              className={cn(inputClass(), 'resize-none')}
              maxLength={1000}
            />
          </Field>
        </div>
      </div>

      <div className="mt-8">
        <label className="flex items-start gap-3 text-sm text-muted-foreground">
          <input
            id="quote-privacy"
            type="checkbox"
            checked={fields.privacy}
            onChange={(e) => update('privacy', e.target.checked)}
            className="mt-0.5 size-4 shrink-0 accent-[var(--accent)]"
            aria-invalid={!!errors.privacy}
            aria-describedby={errors.privacy ? 'quote-privacy-error' : undefined}
          />
          {t.privacy}
        </label>
        {errors.privacy ? (
          <p id="quote-privacy-error" className="mt-2 text-xs text-destructive">
            {errors.privacy}
          </p>
        ) : null}
      </div>

      <div className="mt-10 flex flex-col gap-4 sm:flex-row sm:items-center">
        <button
          type="submit"
          className="group inline-flex items-center justify-center gap-3 bg-primary px-7 py-4 text-xs font-medium uppercase tracking-[0.2em] text-primary-foreground transition-colors hover:bg-primary/85"
        >
          <WhatsAppIcon className="size-4" />
          {t.submit}
          <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={onEmail}
          className="text-sm text-muted-foreground underline underline-offset-4 transition-colors hover:text-foreground"
        >
          {t.submitEmail}
        </button>
      </div>

      <div aria-live="polite">
        {sent ? (
          <p id="quote-success" className="mt-6 flex items-start gap-3 bg-secondary p-4 text-sm">
            <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
            {t.success}
          </p>
        ) : null}
      </div>
    </form>
  )
}

function inputClass(error?: string) {
  return cn(
    'mt-2 block w-full border-0 border-b bg-transparent px-0 py-2.5 text-base outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-accent',
    error ? 'border-destructive' : 'border-input',
  )
}

function Field({
  id,
  label,
  error,
  required,
  children,
}: {
  id: string
  label: string
  error?: string
  required?: boolean
  children: React.ReactNode
}) {
  return (
    <div>
      <label htmlFor={`quote-${id}`} className="text-xs font-medium uppercase tracking-[0.2em] text-muted-foreground">
        {label}
        {required ? <span className="text-accent"> *</span> : null}
      </label>
      {children}
      {error ? (
        <p id={`quote-${id}-error`} className="mt-2 text-xs text-destructive">
          {error}
        </p>
      ) : null}
    </div>
  )
}
