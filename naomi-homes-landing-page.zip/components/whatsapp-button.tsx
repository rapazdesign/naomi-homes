import { whatsappUrl } from '@/lib/site'
import { WhatsAppIcon } from './whatsapp-icon'

export function WhatsAppButton({ label, message }: { label: string; message: string }) {
  return (
    <a
      href={whatsappUrl(message)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      className="group fixed bottom-5 right-5 z-40 flex items-center gap-3 rounded-full bg-[#25D366] p-4 text-white shadow-lg shadow-black/20 transition-transform hover:scale-105 sm:bottom-8 sm:right-8"
    >
      <WhatsAppIcon className="size-6" />
      <span className="hidden max-w-0 overflow-hidden whitespace-nowrap text-sm font-medium transition-all duration-500 group-hover:max-w-xs sm:inline">
        {label}
      </span>
    </a>
  )
}
