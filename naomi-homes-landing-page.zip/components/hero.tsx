import { ArrowDownRight, ArrowRight } from 'lucide-react'
import Image from 'next/image'
import type { Dictionary } from '@/lib/i18n'

export function Hero({ t }: { t: Dictionary['hero'] }) {
  return (
    <section
      aria-labelledby="hero-title"
      className="relative isolate overflow-hidden bg-primary text-primary-foreground"
    >
      <div className="grid min-h-svh lg:grid-cols-2">
        <div className="flex flex-col justify-end px-6 pb-16 pt-36 lg:order-1 lg:px-10 lg:pb-24 xl:pl-[max(2.5rem,calc((100vw-80rem)/2+2.5rem))]">
          <p className="text-xs font-medium uppercase tracking-[0.3em] text-primary-foreground/80">
            {t.eyebrow}
          </p>
          <h1
            id="hero-title"
            className="mt-6 text-balance font-serif text-5xl font-light leading-[0.95] tracking-tight sm:text-6xl md:text-7xl"
          >
            {t.titleA} <em className="font-normal italic text-secondary">{t.titleB}</em> {t.titleC}
          </h1>

          <p className="mt-8 max-w-lg text-pretty leading-relaxed text-primary-foreground/85">{t.body}</p>

          <div className="mt-10 flex flex-col gap-3 sm:flex-row">
            <a
              href="#quote"
              className="group inline-flex items-center justify-center gap-3 bg-primary-foreground px-7 py-4 text-xs font-medium uppercase tracking-[0.2em] text-primary transition-colors hover:bg-secondary"
            >
              {t.ctaPrimary}
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
            </a>
            <a
              href="#projects"
              className="group inline-flex items-center justify-center gap-3 border border-primary-foreground/50 px-7 py-4 text-xs font-medium uppercase tracking-[0.2em] transition-colors hover:bg-primary-foreground/10"
            >
              {t.ctaSecondary}
              <ArrowDownRight className="size-4" aria-hidden="true" />
            </a>
          </div>

          <div className="mt-14 flex items-center gap-4 border-t border-primary-foreground/20 pt-6 text-xs uppercase tracking-[0.25em] text-primary-foreground/70">
            <span aria-hidden="true" className="size-1.5 rounded-full bg-accent" />
            {t.badge}
          </div>
        </div>

        <div className="relative aspect-[960/1096] w-full lg:order-2 lg:aspect-auto lg:min-h-svh">
          <Image
            src="/images/hero-naomi-kitchen.jpg"
            alt={t.imageAlt}
            fill
            priority
            sizes="(min-width: 1024px) 50vw, 100vw"
            className="object-cover object-[center_70%]"
          />
          <div
            aria-hidden="true"
            className="absolute inset-x-0 top-0 hidden h-40 bg-gradient-to-b from-primary/70 to-transparent lg:block"
          />
        </div>
      </div>
    </section>
  )
}
