import { cn } from '@/lib/utils'

export function Eyebrow({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <p
      className={cn(
        'flex items-center gap-3 text-xs font-medium uppercase tracking-[0.28em] text-accent',
        className,
      )}
    >
      <span aria-hidden="true" className="h-px w-8 bg-current" />
      {children}
    </p>
  )
}

export function SectionHeading({
  id,
  eyebrow,
  title,
  body,
  className,
}: {
  id?: string
  eyebrow: string
  title: string
  body?: string
  className?: string
}) {
  return (
    <div className={cn('max-w-2xl', className)}>
      <Eyebrow>{eyebrow}</Eyebrow>
      <h2
        id={id}
        className="mt-5 text-balance font-serif text-4xl font-light leading-[1.05] tracking-tight md:text-5xl lg:text-6xl"
      >
        {title}
      </h2>
      {body ? (
        <p className="mt-6 max-w-xl text-pretty leading-relaxed text-muted-foreground">{body}</p>
      ) : null}
    </div>
  )
}
