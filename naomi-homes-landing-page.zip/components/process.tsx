import { MapPin } from 'lucide-react'
import type { Dictionary } from '@/lib/i18n'
import { SectionHeading } from './section-heading'

export function Process({ t, areas }: { t: Dictionary['process']; areas: Dictionary['areas'] }) {
  return (
    <section
      id="process"
      aria-labelledby="process-title"
      className="scroll-mt-20 border-t border-border bg-secondary py-24 lg:py-36"
    >
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeading id="process-title" eyebrow={t.eyebrow} title={t.title} />

        <ol className="mt-16 grid gap-10 md:grid-cols-2 lg:mt-20 lg:grid-cols-4 lg:gap-0">
          {t.steps.map((step, i) => (
            <li key={step.title} className="border-t border-foreground/20 pt-8 lg:pr-10">
              <span className="font-serif text-6xl font-light italic text-accent">
                {String(i + 1).padStart(2, '0')}
              </span>
              <h3 className="mt-6 font-serif text-2xl">{step.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
            </li>
          ))}
        </ol>

        <div className="mt-20 flex flex-col gap-6 border-t border-foreground/20 pt-10 lg:flex-row lg:items-center lg:gap-12">
          <h3 className="flex shrink-0 items-center gap-2 text-xs font-medium uppercase tracking-[0.25em]">
            <MapPin className="size-4 text-accent" aria-hidden="true" />
            {areas.title}
          </h3>
          <ul className="flex flex-wrap gap-x-6 gap-y-2 font-serif text-xl text-foreground/80">
            {areas.list.map((area) => (
              <li key={area}>{area}</li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
