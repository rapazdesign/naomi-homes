'use client'

import { Menu, X } from 'lucide-react'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import type { Dictionary, Locale } from '@/lib/i18n'
import { locales } from '@/lib/i18n'
import { cn } from '@/lib/utils'

export function SiteHeader({ lang, t }: { lang: Locale; t: Dictionary['nav'] }) {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const links = [
    { href: '#materials', label: t.materials },
    { href: '#projects', label: t.projects },
    { href: '#process', label: t.process },
    { href: '#quote', label: t.contact },
  ]

  const solid = scrolled || open

  return (
    <header
      className={cn(
        'fixed inset-x-0 top-0 z-50 transition-colors duration-500',
        solid
          ? 'border-b border-border bg-background/90 text-foreground backdrop-blur-md'
          : 'bg-transparent text-primary-foreground',
      )}
    >
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6 lg:px-10">
        <Link href={`/${lang}`} className="flex flex-col leading-none" aria-label="Naomi Homes">
          <span className="font-serif text-2xl font-medium tracking-wide">Naomi Homes</span>
          <span className="mt-1 text-[0.6rem] uppercase tracking-[0.35em] opacity-70">
            Stone & Surfaces
          </span>
        </Link>

        <nav aria-label="Main" className="hidden items-center gap-10 lg:flex">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm tracking-wide opacity-80 transition-opacity hover:opacity-100"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <LanguageSwitch lang={lang} label={t.language} />
          <a
            href="#quote"
            className={cn(
              'hidden border px-5 py-2.5 text-xs font-medium uppercase tracking-[0.2em] transition-colors md:inline-flex',
              solid
                ? 'border-primary bg-primary text-primary-foreground hover:bg-primary/85'
                : 'border-primary-foreground/60 hover:bg-primary-foreground hover:text-primary',
            )}
          >
            {t.quote}
          </a>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-nav"
            className="inline-flex size-10 items-center justify-center lg:hidden"
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
            <span className="sr-only">{open ? t.close : t.menu}</span>
          </button>
        </div>
      </div>

      {open ? (
        <nav id="mobile-nav" aria-label="Mobile" className="border-t border-border lg:hidden">
          <ul className="mx-auto flex max-w-7xl flex-col px-6 py-6">
            {links.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="block py-3 font-serif text-2xl"
                >
                  {link.label}
                </a>
              </li>
            ))}
            <li className="pt-4">
              <a
                href="#quote"
                onClick={() => setOpen(false)}
                className="inline-flex w-full justify-center bg-primary px-5 py-3.5 text-xs font-medium uppercase tracking-[0.2em] text-primary-foreground"
              >
                {t.quote}
              </a>
            </li>
          </ul>
        </nav>
      ) : null}
    </header>
  )
}

function LanguageSwitch({ lang, label }: { lang: Locale; label: string }) {
  return (
    <div role="group" aria-label={label} className="flex items-center text-xs font-medium tracking-[0.2em]">
      {locales.map((locale, i) => (
        <span key={locale} className="flex items-center">
          {i > 0 ? <span aria-hidden="true" className="mx-2 opacity-40">/</span> : null}
          <Link
            href={`/${locale}`}
            hrefLang={locale}
            aria-current={locale === lang ? 'true' : undefined}
            className={cn(
              'uppercase transition-opacity',
              locale === lang ? 'opacity-100' : 'opacity-50 hover:opacity-100',
            )}
          >
            {locale}
          </Link>
        </span>
      ))}
    </div>
  )
}
