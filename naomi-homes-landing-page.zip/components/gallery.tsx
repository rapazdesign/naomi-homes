import Image from 'next/image'
import type { Dictionary } from '@/lib/i18n'
import { cn } from '@/lib/utils'
import { SectionHeading } from './section-heading'

const layout = [
  'sm:col-span-2 sm:row-span-2',
  'sm:row-span-2',
  '',
  '',
  'sm:col-span-2',
  '',
  '',
]

export function Gallery({ t }: { t: Dictionary['gallery'] }) {
  return (
    <section id="projects" aria-labelledby="projects-title" className="scroll-mt-20 py-24 lg:py-36">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeading id="projects-title" eyebrow={t.eyebrow} title={t.title} body={t.body} />

        <ul className="mt-16 grid auto-rows-[280px] grid-cols-1 gap-3 sm:grid-cols-2 lg:mt-20 lg:auto-rows-[300px] lg:grid-cols-4">
          {t.items.map((item, i) => (
            <li key={item.src} className={cn('group relative overflow-hidden bg-muted', layout[i])}>
              <figure className="h-full">
                <Image
                  src={item.src}
                  alt={`${item.title} — ${item.material}, ${item.place}`}
                  fill
                  sizes="(min-width: 1024px) 50vw, (min-width: 640px) 50vw, 100vw"
                  className="object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-105"
                />
                <div
                  aria-hidden="true"
                  className="absolute inset-0 bg-gradient-to-t from-primary/80 via-primary/0 to-primary/0 opacity-80 transition-opacity duration-500 group-hover:opacity-100"
                />
                <figcaption className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-5 text-primary-foreground lg:p-6">
                  <div>
                    <p className="text-[0.65rem] uppercase tracking-[0.25em] text-primary-foreground/75">
                      {item.place}
                    </p>
                    <p className="mt-1.5 font-serif text-2xl font-light leading-tight">{item.title}</p>
                  </div>
                  <span className="shrink-0 border border-primary-foreground/40 px-3 py-1 text-[0.6rem] uppercase tracking-[0.2em] backdrop-blur-sm">
                    {item.material}
                  </span>
                </figcaption>
              </figure>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
