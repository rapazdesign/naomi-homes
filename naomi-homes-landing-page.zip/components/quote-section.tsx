import { Clock, Mail, MapPin, Phone } from 'lucide-react'
import type { Dictionary } from '@/lib/i18n'
import { site, whatsappUrl } from '@/lib/site'
import { QuoteForm } from './quote-form'
import { SectionHeading } from './section-heading'
import { WhatsAppIcon } from './whatsapp-icon'

export function QuoteSection({
  t,
  materials,
}: {
  t: Dictionary['quote']
  materials: Dictionary['materials']['items']
}) {
  return (
    <section id="quote" aria-labelledby="quote-title" className="scroll-mt-20 py-24 lg:py-36">
      <div className="mx-auto grid max-w-7xl gap-16 px-6 lg:grid-cols-12 lg:gap-20 lg:px-10">
        <div className="lg:col-span-5">
          <SectionHeading id="quote-title" eyebrow={t.eyebrow} title={t.title} body={t.body} />

          <div className="mt-12 border-t border-border pt-8">
            <h3 className="text-xs font-medium uppercase tracking-[0.25em] text-muted-foreground">
              {t.contactTitle}
            </h3>
            <ul className="mt-6 flex flex-col gap-5">
              <li>
                <a
                  href={whatsappUrl(t.whatsappIntro)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center gap-4"
                >
                  <span className="flex size-11 items-center justify-center bg-[#25D366] text-white">
                    <WhatsAppIcon className="size-5" />
                  </span>
                  <span className="font-serif text-2xl transition-colors group-hover:text-accent">
                    WhatsApp
                  </span>
                </a>
              </li>
              <li className="flex items-center gap-4">
                <Phone className="size-4 text-accent" aria-hidden="true" />
                <a href={`tel:+${site.whatsappNumber}`} className="hover:text-accent">
                  {site.phoneDisplay}
                </a>
              </li>
              <li className="flex items-center gap-4">
                <Mail className="size-4 text-accent" aria-hidden="true" />
                <a href={`mailto:${site.email}`} className="hover:text-accent">
                  {site.email}
                </a>
              </li>
              <li className="flex items-center gap-4">
                <MapPin className="size-4 text-accent" aria-hidden="true" />
                {site.address}
              </li>
              <li className="flex items-center gap-4 text-muted-foreground">
                <Clock className="size-4 text-accent" aria-hidden="true" />
                {t.hours}
              </li>
            </ul>
          </div>
        </div>

        <div className="lg:col-span-7">
          <QuoteForm t={t} materials={materials.map((m) => ({ id: m.id, name: m.name }))} />
        </div>
      </div>
    </section>
  )
}
