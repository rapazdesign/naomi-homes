import { Check } from 'lucide-react'
import Image from 'next/image'
import type { Dictionary } from '@/lib/i18n'
import { Eyebrow } from './section-heading'

export function Intro({ t, stats }: { t: Dictionary['intro']; stats: Dictionary['stats'] }) {
  return (
    <section aria-labelledby="intro-title" className="py-24 lg:py-36">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <dl className="grid grid-cols-2 border-y border-border md:grid-cols-4">
          {stats.map((stat, i) => (
            <div
              key={stat.label}
              className={`flex flex-col-reverse gap-2 px-2 py-8 md:px-6 ${i > 0 ? 'md:border-l md:border-border' : ''} ${i % 2 === 1 ? 'border-l border-border md:border-l' : ''} ${i > 1 ? 'border-t border-border md:border-t-0' : ''}`}
            >
              <dt className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{stat.label}</dt>
              <dd className="font-serif text-4xl font-light md:text-5xl">{stat.value}</dd>
            </div>
          ))}
        </dl>

        <div className="mt-24 grid items-center gap-14 lg:mt-32 lg:grid-cols-12 lg:gap-20">
          <div className="relative aspect-[4/5] overflow-hidden lg:col-span-5">
            <Image
              src="/images/project-3.png"
              alt=""
              fill
              sizes="(min-width: 1024px) 40vw, 100vw"
              className="object-cover"
            />
          </div>
          <div className="lg:col-span-7">
            <Eyebrow>{t.eyebrow}</Eyebrow>
            <h2
              id="intro-title"
              className="mt-5 text-balance font-serif text-4xl font-light leading-[1.05] tracking-tight md:text-5xl lg:text-6xl"
            >
              {t.title}
            </h2>
            <p className="mt-8 max-w-xl text-pretty leading-relaxed text-muted-foreground">{t.body}</p>
            <ul className="mt-10 grid gap-x-8 gap-y-4 sm:grid-cols-2">
              {t.points.map((point) => (
                <li key={point} className="flex items-start gap-3 border-t border-border pt-4 text-sm">
                  <Check className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
                  {point}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
