import type { Dictionary } from '@/lib/i18n'
import { site } from '@/lib/site'

export function SiteFooter({ t, nav }: { t: Dictionary['footer']; nav: Dictionary['nav'] }) {
  const year = new Date().getFullYear()
  const links = [
    { href: '#materials', label: nav.materials },
    { href: '#projects', label: nav.projects },
    { href: '#process', label: nav.process },
    { href: '#quote', label: nav.quote },
  ]

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="mx-auto max-w-7xl px-6 pb-10 pt-20 lg:px-10">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-6">
            <p className="font-serif text-5xl font-light md:text-6xl">Naomi Homes</p>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-primary-foreground/65">{t.tagline}</p>
          </div>
          <nav aria-label={t.navTitle} className="md:col-span-3">
            <h2 className="text-xs uppercase tracking-[0.25em] text-accent">{t.navTitle}</h2>
            <ul className="mt-5 flex flex-col gap-3 text-sm text-primary-foreground/80">
              {links.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="hover:text-primary-foreground">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
          <div className="md:col-span-3">
            <h2 className="text-xs uppercase tracking-[0.25em] text-accent">{t.contactTitle}</h2>
            <address className="mt-5 flex flex-col gap-3 text-sm not-italic text-primary-foreground/80">
              <a href={`mailto:${site.email}`} className="hover:text-primary-foreground">
                {site.email}
              </a>
              <a href={`tel:+${site.whatsappNumber}`} className="hover:text-primary-foreground">
                {site.phoneDisplay}
              </a>
              <span>{site.address}</span>
            </address>
          </div>
        </div>
        <div className="mt-20 flex flex-col gap-2 border-t border-primary-foreground/15 pt-6 text-xs text-primary-foreground/50 sm:flex-row sm:justify-between">
          <p>
            &copy; {year} Naomi Homes. {t.rights}
          </p>
          <p>naomihomes.es</p>
        </div>
      </div>
    </footer>
  )
}
